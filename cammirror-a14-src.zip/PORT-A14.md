# Android 14 / 相机 13.0.6.35 移植说明

上游模块（v5 preview 01）是针对 Android 15 + 相机 13.1.0.0 调的。在这台 14 系统的 X Flip 上，
hook 能装上、`isPreviewMirror()` 也确实被调用，但画面依旧左右翻转——因为这一版真正决定预览镜像的是
viengine 输入层的 `Input.setMirror()`，而 `SurfaceOutput.setMirror()` 在这版是"再翻一次"，
两个一起改会互相抵消。

## 这版改了什么

`bin/cammirror.js`：

| 版本 | 模式 C 的镜像做法 |
| --- | --- |
| Android 15（相机 13.1.0.0） | 沿用上游：`isPreviewMirror()` 返回 false + `getPreviewSurfaceOutput()` 里 `setMirror(false)` |
| Android 14（相机 13.0.6.35） | 新：只 hook `com.vivo.viengine.data.input.Input.setMirror()`，且仅对调用栈里出现 `PreviewRenderRequestBuilder` 的预览请求改 false；不再碰 `SurfaceOutput` |

判断依据：进程启动时读 `Build.VERSION.SDK_INT`，`<= 34` 走新方案。日志里会打印
`mirror strategy: input hook (Android<=14)`。

前置/后摄区分沿用上游逻辑：`mCameraFacing == 0`（前摄）或 `isRearSelfieState()` /
`isRearSelfieExiting()` 为真时不动，保证自拍取景仍是镜像；内屏（`isFlipOuterScreen()` 为假）也不动。

## 实测

- 原生外屏预览截图 A；装模块后截图 E；`E` 与 `A` 的水平镜像版本平均像素差 8.2，与 `A` 本身差 54.7
  → 画面确实翻正，且没有翻两次
- 只改 `isPreviewMirror` / `SurfaceOutput`（上游做法）时，E 与 A 的差只有 11.9 → 这条链路在 13.0.6.35 上无效

## 已知未验证

- 外屏切前摄时是"不动"，理论上保持自拍镜像，但没有实拍对照
- 满血相机（模式 A）同样走新方案，同样未做视觉对照
