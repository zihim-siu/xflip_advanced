# 魔镜应用管理（KernelSU 模块）

在 KernelSU 管理器的模块页面点「打开」，用 WebUI 管理 vivo X Flip 外屏（魔镜）的应用白名单。

## 功能

- 自动读取已安装应用（包名 + 常见应用中文名）
- 搜索、按「未添加 / 已添加」过滤
- 点一下把应用加入魔镜白名单，再点一下移出
- 「白名单」页签可查看/移除全部条目（含已卸载的包）
- 顶栏「＋」可手动输入包名
- 「重启魔镜桌面」让改动立即生效

## 原理

写入两条 secure 设置（魔镜桌面 `com.vivo.fliplauncher` 读取）：

| 键 | 含义 |
| --- | --- |
| `fold_adaptive_screen_app_list` | 放行名单，逗号分隔包名 |
| `fold_adaptive_app_not_in_lab` | 排除名单，只读展示，不会自动改动 |

每次写入后都会回读校验；命令通过 KernelSU WebUI 的 `ksu.exec` 以 root 执行。

## 注意

- 只改设置，不动系统文件；卸载本模块不影响已写入的白名单。
- 重启魔镜桌面会结束 `com.vivo.fliplauncher` 进程，桌面会自动重启，外屏可能闪一下。
- 若应用已加入但外屏不显示，检查它是否在「排除名单」里（列表行会标「排除名单」）。

## 作者与许可

- 作者：**AC极光**（酷安：**AC极光_Official**）
- 许可：[MIT](LICENSE)

## 打包

模块 zip 的根目录就是本目录：

```
magic_mirror_manager.zip
├── module.prop
└── webroot/
    ├── index.html
    ├── app.js
    ├── labels.js
    └── style.css
```

在仓库根目录执行 `Compress-Archive -Path module.prop,webroot -DestinationPath magic_mirror_manager.zip`，
或 `zip -r magic_mirror_manager.zip module.prop webroot` 即可。
