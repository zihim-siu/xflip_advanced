/* 魔镜应用管理 —— KernelSU / ReSukiSU WebUI */
(function () {
  "use strict";

  var KEY_MAIN = "fold_adaptive_screen_app_list";   // 魔镜应用白名单
  var KEY_EX = "fold_adaptive_app_not_in_lab";      // 排除名单
  var LAUNCHER = "com.vivo.fliplauncher";           // 魔镜桌面
  var LABELS = window.APP_LABELS || {};

  var bridgeMode = "";   // sync / promise / callback
  var state = {
    tab: "apps",
    filter: "all",
    q: "",
    showSystem: false,
    pkgs: [],
    whitelist: [],
    excluded: [],
    nativeLabels: {},
    loading: true,
    error: "",
    detail: "",
    busy: false,
    debug: false
  };

  var els = {};
  var toastTimer = 0;
  var searchTimer = 0;
  var cbSeq = 0;

  /* ---------------- KernelSU WebUI 桥 ---------------- */

  function bridge() {
    return window.ksu || window.KSU || window.ksuNext || null;
  }

  /* 不同管理器的返回结构不一样，统一成 {errno, stdout, stderr} */
  function normalize(res) {
    /* 同步 exec 对「无输出」的命令可能返回 null/undefined，按成功处理，写入是否生效靠回读校验 */
    if (res == null) return { errno: 0, stdout: "", stderr: "" };

    if (typeof res === "string") {
      var t = res.replace(/^\s+|\s+$/g, "");
      if (t.charAt(0) === "{" && t.charAt(t.length - 1) === "}") {
        try {
          var o = JSON.parse(t);
          if (o && (o.stdout !== undefined || o.errno !== undefined || o.code !== undefined)) {
            return {
              errno: Number(o.errno != null ? o.errno : o.code) || 0,
              stdout: o.stdout == null ? "" : String(o.stdout),
              stderr: o.stderr == null ? "" : String(o.stderr)
            };
          }
        } catch (e) { /* 普通输出，继续往下走 */ }
      }
      return { errno: 0, stdout: res, stderr: "" };
    }

    if (typeof res === "object") {
      var errno = res.errno != null ? res.errno : (res.code != null ? res.code : res.exitCode);
      return {
        errno: Number(errno) || 0,
        stdout: res.stdout != null ? String(res.stdout) : (res.output != null ? String(res.output) : ""),
        stderr: res.stderr != null ? String(res.stderr) : (res.error != null ? String(res.error) : "")
      };
    }

    return { errno: 0, stdout: String(res), stderr: "" };
  }

  /*
   * WebUI-Next / ReSukiSU：exec(cmd) 同步返回 stdout 字符串；
   * exec(cmd, callbackName) 里的第二个参数是"回调函数名字符串"，不是函数对象。
   * 传函数进去 Java 那边只会拿到函数源码，回调永远不触发，所以必须先走同步形式。
   */
  function execRaw(cmd) {
    return new Promise(function (resolve) {
      var k = bridge();
      if (!k || typeof k.exec !== "function") {
        resolve({ errno: -1, stdout: "", stderr: "KernelSU WebUI 接口不可用" });
        return;
      }

      var settled = false;
      var timer = 0;
      function done(r) {
        if (settled) return;
        settled = true;
        if (timer) clearTimeout(timer);
        resolve(r);
      }

      /* 1) 同步形式 */
      try {
        var r = k.exec(cmd);
        if (r && typeof r.then === "function") {
          bridgeMode = bridgeMode || "promise";
          r.then(function (v) { done(normalize(v)); }, function (e) {
            done({ errno: -1, stdout: "", stderr: String((e && e.message) || e) });
          });
          return;
        }
        if (r !== undefined) {
          bridgeMode = bridgeMode || "sync";
          done(normalize(r));
          return;
        }
      } catch (e) {
        /* 同步形式不可用，落到回调形式 */
      }

      /* 2) 回调形式：把回调函数挂到 window 上，把名字传给 Java */
      bridgeMode = bridgeMode || "callback";
      var name = "__ksuCb" + (++cbSeq);
      timer = setTimeout(function () {
        delete window[name];
        done({ errno: -1, stdout: "", stderr: "命令超时" });
      }, 20000);

      window[name] = function (a, b, c) {
        delete window[name];
        if (typeof a === "string") return done(normalize(a));
        if (a && typeof a === "object") return done(normalize(a));
        done(normalize({ errno: a, stdout: b, stderr: c }));
      };

      try {
        k.exec(cmd, name);
      } catch (e2) {
        try {
          k.exec(cmd, "", name);
        } catch (e3) {
          done({ errno: -1, stdout: "", stderr: "调用失败：" + ((e3 && e3.message) || e3) });
        }
      }
    });
  }

  function sh(cmd) { return execRaw(cmd); }
  function trim(s) { return String(s == null ? "" : s).trim(); }
  function firstLine(s) { return trim(s).split("\n")[0].slice(0, 120); }

  /* ---------------- 数据 ---------------- */

  function parseCsv(text) {
    var s = trim(text);
    if (!s || s === "null") return [];
    return s.split(",").map(trim).filter(Boolean);
  }

  /* 兼容两种返回：正常多行，以及被管理器截成"只剩最后一行"时我们用 tr 压成的单行 */
  function parsePackages(out) {
    var set = {};
    String(out || "").split(/\s+/).forEach(function (tok) {
      var m = /^package:([A-Za-z0-9_.]+)$/.exec(tok);
      if (m) set[m[1]] = true;
    });
    return Object.keys(set);
  }

  /* /data/system/packages.list 的包名（已用 cut + tr 压成一行） */
  function parsePackagesList(out) {
    var set = {};
    String(out || "").split(/\s+/).forEach(function (tok) {
      if (/^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z0-9_]+)+$/.test(tok)) set[tok] = true;
    });
    return Object.keys(set);
  }

  /* 兜底路径下用来粗分系统应用 */
  function isSystemPkg(name) {
    return /^(android|com\.android|com\.vivo|com\.bbk|com\.iqoo|com\.qualcomm|com\.qti|org\.codeaurora|com\.google\.android|com\.mediatek|com\.vivo\.)/.test(name);
  }

  /* 把一次加载的关键信息落到 /data/local/tmp/mmdiag.txt，方便命令行排查 */
  function diagWrite(obj) {
    try {
      var txt = JSON.stringify(obj || {});
      if (txt.indexOf("MMEOF") >= 0) txt = txt.split("MMEOF").join("MM_EOF");
      sh("cat > /data/local/tmp/mmdiag.txt <<'MMEOF'\n" + txt + "\nMMEOF\n");
    } catch (e) {}
  }

  /* 管理器的原生包列表接口（WebUI-Next 系），只在 pm 拿不到东西时兜底用 */
  function nativePackages(kind) {
    var k = bridge();
    if (!k || typeof k.listPackages !== "function") return null;
    try {
      var raw = k.listPackages(kind);
      if (raw && typeof raw.then === "function") return null;
      var arr = typeof raw === "string" ? JSON.parse(raw) : raw;
      if (arr && !Array.isArray(arr)) {
        var keys = ["packages", "data", "list", "apps"];
        for (var i = 0; i < keys.length; i++) {
          if (Array.isArray(arr[keys[i]])) { arr = arr[keys[i]]; break; }
        }
      }
      if (!Array.isArray(arr) || !arr.length) return null;
      var out = [];
      arr.forEach(function (item) {
        if (typeof item === "string" && /^[A-Za-z0-9_.]+$/.test(item)) {
          out.push({ name: item, system: kind === "system" });
        } else if (item && (item.packageName || item.package)) {
          var n = item.packageName || item.package;
          if (/^[A-Za-z0-9_.]+$/.test(n)) {
            out.push({ name: n, system: kind === "system" });
            var lb = item.label || item.appName || item.name;
            if (lb && lb !== n) state.nativeLabels[n] = String(lb);
          }
        }
      });
      return out.length ? out : null;
    } catch (e) {
      return null;
    }
  }

  function loadAll() {
    state.loading = true;
    state.error = "";
    state.detail = "";
    render();

    return Promise.all([
      sh("settings get secure " + KEY_MAIN),
      sh("settings get secure " + KEY_EX),
      /* 管理器（ReSukiSU / WebUI-Next）的同步 exec 只回最后一行，所以在 shell 里先压成一行 */
      sh("pm list packages -3 2>/dev/null | tr '\\n' ' '"),
      sh("pm list packages -s 2>/dev/null | tr '\\n' ' '")
    ]).then(function (res) {
      var main = res[0], ex = res[1], user = res[2], sys = res[3];

      var wlRaw = trim(main.stdout);
      if (main.errno !== 0 && !wlRaw) {
        throw new Error("读取魔镜设置失败：" + (trim(main.stderr) || "命令没有输出"));
      }
      if (!wlRaw && main.stderr) {
        throw new Error("读取魔镜设置失败：" + firstLine(main.stderr));
      }

      state.whitelist = parseCsv(main.stdout);
      state.excluded = parseCsv(ex.stdout);

      var userList = parsePackages(user.stdout);
      var sysList = parsePackages(sys.stdout);
      var via = "pm";

      /* 兜底 1：管理器自带的包列表接口（返回 JSON 数组，天然一行） */
      if (userList.length + sysList.length < 3) {
        var nu = nativePackages("user");
        var ns = nativePackages("system");
        if ((nu ? nu.length : 0) + (ns ? ns.length : 0) >= 3) {
          userList = (nu || []).map(function (p) { return p.name; });
          sysList = (ns || []).map(function (p) { return p.name; });
          via = "listPackages";
        }
      }

      /* 兜底 2：直接读系统的已安装清单（root 可读，含全部包名） */
      if (userList.length + sysList.length < 3) {
        var pl = sh("cat /data/system/packages.list 2>/dev/null | cut -d' ' -f1 | tr '\\n' ' '");
        var fromList = parsePackagesList(pl.stdout);
        if (fromList.length) {
          userList = fromList.filter(function (n) { return !isSystemPkg(n); });
          sysList = fromList.filter(isSystemPkg);
          via = "packages.list";
        }
      }

      /* 兜底 3：不分用户/系统的 pm 列表 */
      if (userList.length + sysList.length < 3) {
        var pa = sh("pm list packages 2>/dev/null | tr '\\n' ' '");
        var allP = parsePackages(pa.stdout);
        if (allP.length) {
          userList = allP;
          sysList = [];
          via = "pm-all";
        }
      }

      if (userList.length + sysList.length < 3) {
        diagWrite({
          via: via,
          mode: bridgeMode,
          wl: wlRaw.slice(0, 120),
          userOut: user.stdout.slice(0, 160),
          userErr: user.stderr.slice(0, 160),
          sysErr: sys.stderr.slice(0, 160)
        });
        var why = trim(user.stderr) || trim(user.stdout) || "pm 没有返回任何包名";
        throw new Error("读取应用列表失败：" + firstLine(why));
      }

      var map = {};
      userList.forEach(function (n) { map[n] = { name: n, system: false }; });
      sysList.forEach(function (n) { if (!map[n]) map[n] = { name: n, system: true }; });
      state.pkgs = Object.keys(map).map(function (n) { return map[n]; });

      state.loading = false;
      render();
      updateCount();
      diagWrite({
        via: via,
        mode: bridgeMode,
        userCount: userList.length,
        sysCount: sysList.length,
        total: state.pkgs.length,
        wlCount: state.whitelist.length,
        userHead: user.stdout.slice(0, 120),
        sysHead: sys.stdout.slice(0, 120)
      });
    }).catch(function (e) {
      state.loading = false;
      state.error = (e && e.message) ? e.message : String(e);
      state.detail = "bridge=" + (typeof (bridge() && bridge().exec)) + " mode=" + (bridgeMode || "?");
      render();
    });
  }

  /* ---------------- 写回 ---------------- */

  function writeList(next) {
    if (state.busy) return Promise.reject(new Error("上一次写入还没完成"));
    state.busy = true;

    var value = next.join(",");
    var cmd = value
      ? "settings put secure " + KEY_MAIN + " " + value
      : "settings put secure " + KEY_MAIN + " ''";

    return sh(cmd).then(function (r) {
      if (r.errno !== 0 && trim(r.stderr)) throw new Error(firstLine(r.stderr));
      return sh("settings get secure " + KEY_MAIN);
    }).then(function (r) {
      if (parseCsv(r.stdout).join(",") !== value) throw new Error("回读不一致，可能被系统拦截");
      state.whitelist = next.slice();
      render();
      updateCount();
    }).then(function () {
      state.busy = false;
    }, function (err) {
      state.busy = false;
      throw err;
    });
  }

  function addPkg(pkg) {
    pkg = trim(pkg);
    if (!pkg) return;
    if (state.busy) { toast("稍等，正在写入"); return; }
    if (!/^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z0-9_]+)+$/.test(pkg)) { toast("包名格式不对：" + pkg); return; }
    if (state.whitelist.indexOf(pkg) >= 0) { toast("已经在白名单里了"); return; }

    writeList(state.whitelist.concat(pkg)).then(function () {
      toast(state.excluded.indexOf(pkg) >= 0 ? "已添加（它在排除名单里，可能仍不显示）" : "已添加 " + pkg);
    }).catch(function (e) {
      toast("失败：" + ((e && e.message) || e));
    });
  }

  function removePkg(pkg) {
    if (state.busy) { toast("稍等，正在写入"); return; }
    var next = state.whitelist.filter(function (n) { return n !== pkg; });

    writeList(next).then(function () {
      toast("已移除 " + pkg);
    }).catch(function (e) {
      toast("失败：" + ((e && e.message) || e));
    });
  }

  function togglePkg(pkg) {
    if (state.whitelist.indexOf(pkg) >= 0) removePkg(pkg);
    else addPkg(pkg);
  }

  function restartLauncher() {
    return sh("for p in $(pidof " + LAUNCHER + "); do kill -9 $p; done; echo ok")
      .then(function (r) {
        toast(r.errno === 0 ? "已重启魔镜桌面" : "重启失败");
      });
  }

  /* ---------------- 渲染 ---------------- */

  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function label(name) { return state.nativeLabels[name] || LABELS[name] || ""; }
  function title(name) { return state.nativeLabels[name] || LABELS[name] || name; }

  function visibleRows() {
    var q = state.q.trim().toLowerCase();
    var wl = state.whitelist;
    var rows = state.pkgs;

    if (!state.showSystem) rows = rows.filter(function (r) { return !r.system; });
    if (state.filter === "in") {
      rows = rows.filter(function (r) { return wl.indexOf(r.name) >= 0; });
      var have = {};
      state.pkgs.forEach(function (p) { have[p.name] = true; });
      rows = rows.concat(wl.filter(function (n) { return !have[n]; }).map(function (n) {
        return { name: n, system: false, missing: true };
      }));
    }
    if (state.filter === "out") rows = rows.filter(function (r) { return wl.indexOf(r.name) < 0; });
    if (q) {
      rows = rows.filter(function (r) {
        return r.name.toLowerCase().indexOf(q) >= 0 || label(r.name).toLowerCase().indexOf(q) >= 0;
      });
    }

    return rows.slice().sort(function (a, b) {
      return title(a.name).localeCompare(title(b.name), "zh-Hans-CN");
    });
  }

  function rowHtml(name, added, sub, actionText, extraClass) {
    return '<button class="row' + (added ? " added" : "") + (extraClass ? " " + extraClass : "") +
      '" data-pkg="' + esc(name) + '">' +
      '<span class="txt"><span class="name">' + esc(title(name)) + "</span>" +
      '<span class="pkg">' + esc(sub) + "</span></span>" +
      '<span class="act' + (added ? " on" : "") + '">' + esc(actionText) + "</span>" +
      "</button>";
  }

  function setStatus(text, isError) {
    var el = els.status;
    if (!el) return;
    if (!text) { el.hidden = true; el.textContent = ""; return; }
    el.hidden = false;
    el.textContent = text;
    el.className = "status" + (isError ? " err" : "");
  }

  function render() {
    var list = els.list;
    if (state.loading) { list.innerHTML = '<div class="hint">正在读取应用列表…</div>'; return; }

    if (state.error) {
      list.innerHTML = '<div class="hint err">' + esc(state.error) + "</div>" +
        '<div class="hint"><button class="btn" id="retry">重试</button></div>' +
        (state.detail && state.debug ? '<div class="hint">' + esc(state.detail) + "</div>" : "");
      var retry = document.getElementById("retry");
      if (retry) retry.addEventListener("click", loadAll);
      setStatus(state.error, true);
      return;
    }

    setStatus("");

    if (state.tab === "wl") {
      var wl = state.whitelist;
      var kw = state.q.trim().toLowerCase();
      if (kw) wl = wl.filter(function (n) { return n.toLowerCase().indexOf(kw) >= 0 || label(n).toLowerCase().indexOf(kw) >= 0; });
      if (!wl.length) { list.innerHTML = '<div class="hint">白名单为空</div>'; setStatus("白名单 · 0"); return; }
      var known = {};
      state.pkgs.forEach(function (p) { known[p.name] = true; });
      list.innerHTML = wl.map(function (name) {
        return rowHtml(name, true, name + (known[name] ? "" : " · 未安装"), "移除", known[name] ? "" : "miss");
      }).join("");
      setStatus("白名单 · " + wl.length + " 个");
      return;
    }

    var rows = visibleRows();
    var viewName = state.filter === "in" ? "已添加" : (state.filter === "out" ? "未添加" : "全部应用");
    setStatus(viewName + (state.showSystem ? "（含系统）" : "") + " · " + rows.length + " / " + state.pkgs.length +
      (state.debug ? " · bridge=" + (bridgeMode || "?") : ""));

    if (!rows.length) {
      list.innerHTML = '<div class="hint">没有匹配的应用' +
        (state.showSystem ? "" : "<br>系统应用默认隐藏，点「含系统」查看") + "</div>";
      return;
    }

    list.innerHTML = rows.map(function (r) {
      var added = state.whitelist.indexOf(r.name) >= 0;
      var excluded = state.excluded.indexOf(r.name) >= 0;
      var sub = r.missing
        ? r.name + " · 未安装"
        : r.name + (r.system ? " · 系统" : "") + (excluded ? " · 排除名单" : "");
      return rowHtml(r.name, added, sub, added ? "已添加" : "添加", r.missing ? "miss" : "");
    }).join("");
  }

  function updateCount() {
    if (!els.count) return;
    els.count.textContent = state.pkgs.length + " 应用 · " + state.whitelist.length + " 项";
  }

  function toast(msg) {
    var t = els.toast;
    t.textContent = msg;
    t.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove("show"); }, 2200);
  }

  /* ---------------- 事件 ---------------- */

  function bind() {
    els.q.addEventListener("input", function () {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(function () { state.q = els.q.value; render(); }, 150);
    });

    document.getElementById("tabs").addEventListener("click", function (e) {
      var t = e.target.closest(".tab");
      if (!t) return;
      state.tab = t.getAttribute("data-tab");
      Array.prototype.forEach.call(document.querySelectorAll(".tab"), function (b) {
        b.classList.toggle("on", b === t);
      });
      render();
    });

    document.querySelector(".chips").addEventListener("click", function (e) {
      var c = e.target.closest(".chip");
      if (!c) return;
      if (c.id === "chipSys") {
        state.showSystem = !state.showSystem;
        c.classList.toggle("on", state.showSystem);
        render();
        return;
      }
      state.filter = c.getAttribute("data-filter");
      Array.prototype.forEach.call(document.querySelectorAll(".chip[data-filter]"), function (b) {
        b.classList.toggle("on", b === c);
      });
      render();
    });

    els.list.addEventListener("click", function (e) {
      var row = e.target.closest(".row");
      if (!row) return;
      var pkg = row.getAttribute("data-pkg");
      if (pkg) togglePkg(pkg);
    });

    document.getElementById("btnReload").addEventListener("click", function () {
      loadAll().then(function () { toast("已刷新"); });
    });

    document.getElementById("btnRestart").addEventListener("click", restartLauncher);

    document.getElementById("btnManual").addEventListener("click", openModal);
    document.getElementById("modalCancel").addEventListener("click", closeModal);
    document.getElementById("modalOk").addEventListener("click", submitManual);
    els.manualInput.addEventListener("keydown", function (e) {
      if (e.key === "Enter") submitManual();
    });
    els.modal.addEventListener("click", function (e) {
      if (e.target === els.modal) closeModal();
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && !els.modal.hidden) closeModal();
    });

    /* 长按标题：显示/隐藏调试信息 */
    var pressTimer = 0;
    els.title.addEventListener("touchstart", function () {
      pressTimer = setTimeout(function () { state.debug = !state.debug; render(); toast(state.debug ? "调试信息已开" : "调试信息已关"); }, 600);
    });
    els.title.addEventListener("touchend", function () { clearTimeout(pressTimer); });
    els.title.addEventListener("mousedown", function () {
      pressTimer = setTimeout(function () { state.debug = !state.debug; render(); toast(state.debug ? "调试信息已开" : "调试信息已关"); }, 600);
    });
    els.title.addEventListener("mouseup", function () { clearTimeout(pressTimer); });
  }

  function openModal() {
    els.modal.hidden = false;
    els.manualInput.value = "";
    setTimeout(function () { els.manualInput.focus(); }, 30);
  }

  function closeModal() {
    els.modal.hidden = true;
    els.manualInput.blur();
  }

  function submitManual() {
    var v = trim(els.manualInput.value);
    closeModal();
    if (v) addPkg(v);
  }

  /* ---------------- 启动 ---------------- */

  function init() {
    els.list = document.getElementById("list");
    els.q = document.getElementById("q");
    els.count = document.getElementById("count");
    els.toast = document.getElementById("toast");
    els.modal = document.getElementById("modal");
    els.manualInput = document.getElementById("manualInput");
    els.status = document.getElementById("status");
    els.title = document.querySelector(".title");

    bind();

    if (!bridge()) {
      state.loading = false;
      state.error = "没有检测到 KernelSU 的 WebUI 接口。请从管理器 → 模块 → 本模块 → 「打开」进入。";
      render();
      return;
    }

    sh("id").then(function (r) {
      if (!/uid=0/.test(r.stdout)) {
        state.loading = false;
        state.error = "当前不是 root 身份（uid≠0）。请在 KernelSU / ReSukiSU 里给管理器授权后再打开。";
        render();
        return;
      }
      loadAll();
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  /* 调试用：浏览器控制台里可检查解析结果与桥接方式 */
  window.__MM = {
    parseCsv: parseCsv,
    parsePackages: parsePackages,
    visibleRows: visibleRows,
    execRaw: execRaw,
    state: state,
    mode: function () { return bridgeMode; }
  };
})();
