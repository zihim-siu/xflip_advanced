# Skyward for vivo X Flip（PD2256）— 外屏移植

把 [Skyward](https://github.com/kirklin/skyward)（Rust 写的 recovery）移植到 vivo X Flip，
页面默认显示在外屏（「魔镜」）上，外屏 422×682、density 240。

基于 [Qingizi7/Skyward-PD2301](https://github.com/Qingizi7/Skyward-PD2301) 的 PD2301 适配继续改（其原 README 见 [docs/README-PD2301.md](docs/README-PD2301.md)）。

- **移植 / 维护**：AC极光　酷安：**AC极光_Official**
- **上游**：Kirk Lin（Skyward）、Qingizi7（PD2301 适配）
- **许可**：[GPL-3.0-or-later](LICENSE)（继承上游，改动同样以 GPL 发布）

## 外屏参数

| 项 | 值 | 依据 |
| --- | --- | --- |
| 连接器 | DSI-2 | `/sys/class/drm/card0-DSI-2`，两块屏都 connected，原版「取第一个」会拿到内屏 |
| 分辨率 | 422×682（竖） | 该连接器的 DRM mode `422x682x60cmd` |
| 旋转 | 180° | 面板扫描方向与整机上下相反，提交时整帧反转 |
| density | 240 | 外屏原生 300（约 225dp 宽），太窄放不下 Skyward 版式 |
| 圆角 | 17 px | `DisplayDeviceInfo` 的 roundedCorners |
| 背光 | `panel1-backlight` | 外屏那一路（max 255；内屏 panel0 是 2047） |
| 面板参数 | `dsi_display1` | `qcom,mdss_dsi_pd2256_sec_bf125rad690c0_rm690c0_nhd_cmd` |
| 触摸 | `vivo_ts_second` | event7；X 是最长边，交换 X/Y，且 X 反向、Y 正向 |
| 模块 | `vivo_ts` | 触摸驱动，来自 vendor / vendor_dlkm |
| 振动 | qcom-haptics | `/sys/class/qcom-haptics/{duration,activate}` |
| WLAN | QCA6490 | 与 PD2301 同一颗 |
| 备份 | modemst1/2、fsg、fsc、persist | 取自 `/dev/block/by-name` 实际分区 |

## 相对上游（PD2301）的改动

1. **`skyward-ui/src/surface.rs`**
   - 新增 `KmsSurface::open_preferred(path, Option<(w, h)>)`：在多个已连接面板里按配置尺寸挑一个；
   - 新增 `KmsSurface::set_rotation(deg)`：`present()` 时按 180° 反转整帧。
2. **`skyward-config`**
   - `[display]` 增加 `backlight`、`panel_param`、`rotate`；
   - `[touch]` 增加 `device`、`swap_xy`、`invert_x`、`invert_y`；
   - 绝对路径校验兼容 Unix 风格路径（方便在 Windows 上跑打包工具）。
3. **`skyward/src/ui.rs`**
   - 用配置尺寸选面板、按名字选背光；
   - `normal_max()` 在面板 DT 节点找不到时退回整段亮度范围（外屏面板节点不在 `/proc/device-tree/soc` 下）。
4. **`skyward/src/input.rs`**
   - 触摸按设备名筛选，按 `swap_xy`/`invert_x`/`invert_y` 变换坐标。
5. **`skyward-ui/src/pages.rs`**
   - 「重启」页改用长页面画布（原来固定一屏，内容超出后滑块划不到）；
   - 关于页署名改为 `Aurora | 酷安：AC极光_Official`，「关于本机」里单独一行显示作者；
   - 版本号显示为 `V1.0`。
6. **`skyward-ui/src/widgets.rs` / `term.rs`**
   - 屏幕键盘整体压矮（244dp → 180dp），给终端多留可视化区域。
7. **新增 `crates/skyward-repack`**
   - 精简版打包工具：只做 `recovery` 子命令，不联网、不读 EROFS，纯 Rust，
     因此在 Windows 上也能构建（不需要 MinGW 或 `lz4` 命令行）。
8. **`skyward-bootimg`**
   - unix-only 部分加 `cfg(unix)`，`encode()` 改用纯 Rust 的 LZ4 legacy 编码。

## 构建与刷入

见 [BUILD.md](BUILD.md)。

## 已知限制

- 外屏是 422×682（281×455 dp），比 Skyward 默认设计的手机屏矮很多。除「重启」页外，
  仍有少数固定一屏画布的页面（语言选择、高级工具、槽位、fastbootd 等）可能内容超出而划不动。
- 外屏面板的 DT 节点不在 `/proc/device-tree/soc` 下，亮度按整段范围处理。
- OTG / fastbootd 未适配（PD2301 那套 vusb 端口接管逻辑未必适用）。
- 未适配内屏（1080×2400）布局；`devices/pd2301.toml` 保留作参考。

## 致谢

- [Kirk Lin](https://github.com/kirklin) —— Skyward 本体与 UI 框架
- [Qingizi7](https://github.com/Qingizi7) —— PD2301 适配，本移植的基础
- MiSans、Kirk Mono 字体各自的许可见 `upstream/resources/fonts/`
