#!/bin/bash
# Build Skyward recovery for vivo X Flip (PD2256 / V2256A).
#
# Needs rustup (rust-toolchain.toml pins the toolchain), cargo-ndk and an
# Android NDK. Unlike build.sh this packs with skyward-repack, which needs no
# network access and no EROFS support: give it the phone's own recovery.img.
#
#   ANDROID_NDK_HOME=/path/to/ndk ./build-pd2256.sh <stock recovery.img>
#
# The stock image must be the whole recovery partition as the phone or a full
# OTA package holds it, ending in its AVB footer.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
: "${ANDROID_NDK_HOME:?set ANDROID_NDK_HOME to an Android NDK (r29 was used)}"
STOCK="${1:?give the phone's stock recovery.img}"
export ANDROID_NDK_ROOT="$ANDROID_NDK_HOME"
export PATH="$HOME/.cargo/bin:$PATH"

cd "$ROOT/upstream"

echo "== host: skyward-repack"
cargo build --release -p skyward-repack

echo "== android: skyward"
cargo ndk -t arm64-v8a --platform 30 build --release -p skyward

echo "== android: skyward-system-init (static)"
RUSTFLAGS="-C target-feature=+crt-static" \
  cargo ndk -t arm64-v8a --platform 30 build --release \
  -p skyward-system-init --target-dir target/system-init

echo "== pack: out/skyward-pd2256.img"
mkdir -p "$ROOT/out"
"$ROOT/upstream/target/release/skyward-repack" recovery \
  --stock "$STOCK" \
  --binary "$ROOT/upstream/target/aarch64-linux-android/release/skyward" \
  --system-init "$ROOT/upstream/target/system-init/aarch64-linux-android/release/system-init" \
  --config "$ROOT/devices/pd2256.toml" \
  --font "$ROOT/upstream/resources/fonts/MiSansVF.ttf" \
  --mono "$ROOT/upstream/resources/fonts/KirkMono-Regular.ttf" \
  --mono-license "$ROOT/upstream/resources/fonts/KirkMono-OFL.txt" \
  --libraries "$ROOT/libs" \
  --out "$ROOT/out/skyward-pd2256.img"
