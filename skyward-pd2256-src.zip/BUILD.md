# 构建（PD2256）

从源码构建 X Flip 的 Skyward recovery 镜像。

## 需要

| 项 | 版本 / 说明 |
| --- | --- |
| rustup | `rust-toolchain.toml` 已固定 **1.100.0**，并声明 `aarch64-linux-android` 目标 |
| Android NDK | **r29**（更早的 r26+ 应该也可以，平台用 30） |
| 原厂 recovery | 手机自己的 `recovery.img`，**整块分区**、以 AVB footer 结尾 |
| libs/ | 见下，vivo 专有库，不随源码分发 |

## 原厂 recovery.img 怎么来

任选其一：

```sh
# 1. 从手机直接读（root）
adb shell su -c 'dd if=/dev/block/by-name/recovery_a of=/sdcard/recovery.img'
adb pull /sdcard/recovery.img

# 2. 从全量 OTA 包的 payload.bin 里取出 recovery 分区（payload-dumper-go 等）
payload-dumper-go -p recovery -o stock payload.bin
```

镜像末尾 64 字节以 `AVBf` 开头才算完整的整块分区，否则 `skyward-repack` 会拒绝。

## libs/

`libs/` 放进 recovery 的 `system/lib64`，是恢复环境缺少的四个库：

- `android.hardware.security.{keymint,secureclock,sharedsecret}-V1-ndk_platform.so`
  —— 正常开机由 `/apex/com.android.vndk.v32` 提供，recovery 里没有挂载；
- `libcurl.so` —— vivo 放在 system 分区，recovery 自带的那份缺符号。

它们来自手机自身的分区（`/apex/com.android.vndk.v32/lib64`、`/system/lib64`），
属于 vivo/Google 的二进制，**不要放进公开仓库**；按需从自己手机里 `adb pull`：

```sh
adb shell su -c 'cp /apex/com.android.vndk.v32/lib64/android.hardware.security.*-V1-ndk_platform.so /sdcard/'
adb shell su -c 'cp /system/lib64/libcurl.so /sdcard/'
adb pull /sdcard/android.hardware.security.keymint-V1-ndk_platform.so libs/
...
```

没有这些库时，`--libraries libs` 可以整个去掉，只是部分功能（安全组件、网络）会缺。

## Linux / macOS

```sh
rustup target add aarch64-linux-android
cargo install cargo-ndk
ANDROID_NDK_HOME=$HOME/Android/Sdk/ndk/29.0.14206865 ./build-pd2256.sh stock/recovery.img
```

产物：`out/skyward-pd2256.img`（已填满 recovery 分区并带 AVB footer）。

## Windows（本移植实际用的方式）

Windows 上没有 `cargo-ndk`，直接给 cargo 指定 NDK 的 clang 即可。

1. 安装 rustup 后用 **GNU 主机工具链**，并加目标：

   ```powershell
   rustup toolchain install 1.100.0-x86_64-pc-windows-gnu
   rustup target add aarch64-linux-android --toolchain 1.100.0-x86_64-pc-windows-gnu
   ```

2. 在 `upstream/.cargo/config.toml` 里写（路径换成自己的）：

   ```toml
   [target.x86_64-pc-windows-gnu]
   linker = "…/rustup/toolchains/1.100.0-x86_64-pc-windows-gnu/lib/rustlib/x86_64-pc-windows-gnu/bin/rust-lld.exe"
   rustflags = ["-Clink-self-contained=yes"]

   [target.aarch64-linux-android]
   linker = "…/android-ndk-r29/toolchains/llvm/prebuilt/windows-x86_64/bin/clang.exe"
   rustflags = [
     "-Clink-arg=--target=aarch64-linux-android30",
     "-Clink-arg=--sysroot=…/android-ndk-r29/toolchains/llvm/prebuilt/windows-x86_64/sysroot",
   ]
   ```

   > `-Clink-self-contained=yes` 依赖 `rust-mingw` 组件（rustup 默认会装）；
   > 如果报 `dlltool.exe` 找不到，把 NDK 的 `llvm-dlltool.exe` 复制成 `dlltool.exe` 放进 PATH。

3. 构建（PowerShell，NDK 路径换成自己的）：

   ```powershell
   $ndk = "…\android-ndk-r29\toolchains\llvm\prebuilt\windows-x86_64"
   $env:CC_aarch64_linux_android  = "$ndk\bin\clang.exe"
   $env:AR_aarch64_linux_android  = "$ndk\bin\llvm-ar.exe"
   $env:CFLAGS_aarch64_linux_android = "--target=aarch64-linux-android30 --sysroot=$ndk\sysroot"

   cd upstream
   cargo build --release -p skyward-repack
   cargo build --release -p skyward --target aarch64-linux-android

   $env:RUSTFLAGS = "-C target-feature=+crt-static -Clink-arg=--target=aarch64-linux-android30 -Clink-arg=--sysroot=$ndk\sysroot"
   cargo build --release -p skyward-system-init --target aarch64-linux-android --target-dir target/system-init
   ```

   `skyward-system-init` 必须**静态链接**（recovery 里没有 bionic 的 libc 动态库）。

4. 打包（在 `upstream/` 下）：

   ```powershell
   .\target\release\skyward-repack.exe recovery `
     --stock <stock\recovery.img> `
     --binary .\target\aarch64-linux-android\release\skyward `
     --system-init .\target\system-init\aarch64-linux-android\release\system-init `
     --config ..\devices\pd2256.toml `
     --font .\resources\fonts\MiSansVF.ttf `
     --mono .\resources\fonts\KirkMono-Regular.ttf `
     --mono-license .\resources\fonts\KirkMono-OFL.txt `
     --libraries ..\libs `
     --out ..\out\skyward-pd2256.img
   ```

## 校验

打出来的镜像应当：

- 大小 = recovery 分区大小（PD2256 是 201,326,592 B）；
- 头 8 字节 `ANDROID!`，header v4，kernel_size = 0；
- 末尾 64 字节以 `AVBf` 开头；
- ramdisk 是 LZ4 legacy（`02 21 4c 18`）。

刷入：

```sh
fastboot flash recovery_a out/skyward-pd2256.img
fastboot reboot recovery
```

回滚：把同一条命令换成原厂 `recovery.img`。
