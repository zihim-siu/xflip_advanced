//! A slim stand-in for `skyward-pack recovery`: it does the same work on a
//! stock recovery image, without the package-download and EROFS reading the
//! full pack tool carries, so it builds with nothing but Rust.

use anyhow::{ensure, Context, Result};
use clap::{Parser, Subcommand};
use sha2::{Digest, Sha256};
use skyward_bootimg::{BootImage, Ramdisk};
use skyward_config::ramdisk as paths;
use std::fs::File;
use std::io::{Read, Seek, SeekFrom};
use std::path::{Path, PathBuf};

mod avb;

#[derive(Parser)]
#[command(name = "skyward-repack", about = "Build a Skyward recovery image on top of a stock recovery image")]
struct Cli {
    #[command(subcommand)]
    cmd: Cmd,
}

#[derive(Subcommand)]
enum Cmd {
    /// Build a Skyward recovery image on top of the device's stock recovery.
    Recovery {
        /// The device's stock recovery image: the whole partition, ending in its AVB footer.
        #[arg(long)]
        stock: PathBuf,
        /// Skyward built for the device (aarch64-linux-android).
        #[arg(long)]
        binary: PathBuf,
        /// skyward-system-init built for the device and linked statically.
        #[arg(long)]
        system_init: PathBuf,
        /// devices/<codename>.toml.
        #[arg(long)]
        config: PathBuf,
        #[arg(long)]
        font: PathBuf,
        #[arg(long)]
        mono: PathBuf,
        #[arg(long)]
        mono_license: PathBuf,
        /// Shared libraries to put in system/lib64.
        #[arg(long)]
        libraries: Option<PathBuf>,
        #[arg(long)]
        out: PathBuf,
    },
}

/// The recovery's init script, where its adbd service is described.
const INIT_RC: &str = "system/etc/init/hw/init.rc";

/// Properties filled in from the installed system after boot.
const BUILD_VERSION: [&str; 3] = ["ro.build.version.release", "ro.build.version.security_patch", "ro.vendor.build.security_patch"];

const TASK_PROFILES: &[u8] = include_bytes!("task_profiles.json");
const MTP_RC: &[u8] = include_bytes!("mtp.rc");

fn main() -> Result<()> {
    match Cli::parse().cmd {
        Cmd::Recovery { stock, binary, system_init, config, font, mono, mono_license, libraries, out } => {
            let size = partition_size(&stock)?;
            let mut img = BootImage::read(&stock)?;
            let mut rd = Ramdisk::decode(&img.ramdisk)?;
            if let Some(e) = rd.entries.iter().find(|e| e.name == "FFiles" || e.name.starts_with("twres")) {
                anyhow::bail!("{} holds {}, which is not a stock recovery", stock.display(), e.name);
            }
            let read = |p: &PathBuf| std::fs::read(p).with_context(|| format!("read {}", p.display()));
            skyward_config::DeviceConfig::load(&config)?;
            rd.replace(paths::RECOVERY, read(&binary)?)?;
            let (_, recovery) = paths::RECOVERY.rsplit_once('/').expect("the recovery binary is in a folder");
            for command in paths::COMMANDS {
                rd.link(command, recovery)?;
            }
            rd.add(paths::SYSTEM_INIT, 0o755, read(&system_init)?)?;
            rd.add(paths::CONFIG, 0o644, read(&config)?)?;
            rd.add(paths::FONT, 0o644, read(&font)?)?;
            rd.add(paths::MONO, 0o644, read(&mono)?)?;
            rd.add(paths::MONO_LICENSE, 0o644, read(&mono_license)?)?;
            if rd.find(paths::TASK_PROFILES).is_none() {
                rd.add(paths::TASK_PROFILES, 0o644, TASK_PROFILES.to_vec())?;
            }
            rd.add(paths::MTP_RC, 0o644, MTP_RC.to_vec())?;
            enable_adbd(&mut rd)?;
            if let Some(dir) = &libraries {
                add_libraries(&mut rd, dir)?;
            }
            let stock_props = rd
                .find(paths::PROP_DEFAULT)
                .with_context(|| format!("{} is not in the ramdisk", paths::PROP_DEFAULT))?
                .data
                .clone();
            let mut props = without(&stock_props, &BUILD_VERSION);
            props.extend_from_slice(b"\nro.secure=0\nro.adb.secure=0\nro.debuggable=1\nro.ota.allow_downgrade=true\n");
            rd.replace(paths::PROP_DEFAULT, props)?;
            img.ramdisk = rd.encode()?;
            let bytes = img.to_bytes()?;
            std::fs::write(&out, avb::footed(&bytes, "recovery", size, &Sha256::digest(&bytes))?)
                .with_context(|| format!("write {}", out.display()))?;
            println!("wrote {} ({} bytes)", out.display(), size);
            Ok(())
        }
    }
}

/// The size of the partition `stock` fills: all of it, as its AVB footer ends it.
fn partition_size(stock: &Path) -> Result<usize> {
    let mut file = File::open(stock).with_context(|| format!("open {}", stock.display()))?;
    let size = file.metadata().with_context(|| format!("stat {}", stock.display()))?.len();
    let mut magic = [0u8; 4];
    if size >= 64 {
        file.seek(SeekFrom::Start(size - 64)).with_context(|| format!("seek in {}", stock.display()))?;
        file.read_exact(&mut magic).with_context(|| format!("read {}", stock.display()))?;
    }
    ensure!(
        &magic == b"AVBf",
        "{} does not end in an AVB footer; give the whole recovery partition, as the phone or a full update package holds it",
        stock.display()
    );
    Ok(usize::try_from(size)?)
}

/// Start the recovery's adbd with the default class at boot.
fn enable_adbd(rd: &mut Ramdisk) -> Result<()> {
    const ADBD: &str = "service adbd /system/bin/adbd --root_seclabel=u:r:su:s0 --device_banner=recovery\n    disabled\n";
    const ENABLED: &str = "service adbd /system/bin/adbd --root_seclabel=u:r:su:s0 --device_banner=recovery\n";
    let entry = rd.find(INIT_RC).with_context(|| format!("{INIT_RC} is not in the ramdisk"))?;
    let text = String::from_utf8_lossy(&entry.data).into_owned();
    if !text.contains(ADBD) {
        eprintln!("{INIT_RC} describes adbd otherwise; it is left as it is");
        return Ok(());
    }
    rd.replace(INIT_RC, text.replace(ADBD, ENABLED).into_bytes())?;
    Ok(())
}

/// Put every file in `dir` into system/lib64, replacing what is there.
fn add_libraries(rd: &mut Ramdisk, dir: &Path) -> Result<()> {
    let mut files: Vec<_> = std::fs::read_dir(dir)
        .with_context(|| format!("read {}", dir.display()))?
        .collect::<std::io::Result<Vec<_>>>()
        .with_context(|| format!("read {}", dir.display()))?;
    files.sort_by_key(|entry| entry.file_name());
    for file in files {
        let name = file.file_name();
        let name = name.to_string_lossy();
        let into = format!("system/lib64/{name}");
        let data = std::fs::read(file.path()).with_context(|| format!("read {}", file.path().display()))?;
        match rd.find(&into) {
            Some(e) if e.mode & 0o170000 == 0o100000 => rd.replace(&into, data)?,
            Some(_) => {
                rd.entries.retain(|e| e.name != into);
                rd.add(&into, 0o644, data)?;
            }
            None => rd.add(&into, 0o644, data)?,
        }
    }
    Ok(())
}

/// A property file without the lines that set any of `names`.
fn without(props: &[u8], names: &[&str]) -> Vec<u8> {
    let mut out = Vec::with_capacity(props.len());
    for line in props.split_inclusive(|b| *b == b'\n') {
        let key = line.split(|b| *b == b'=').next().unwrap_or_default();
        if !names.iter().any(|n| n.as_bytes() == key) {
            out.extend_from_slice(line);
        }
    }
    out
}
